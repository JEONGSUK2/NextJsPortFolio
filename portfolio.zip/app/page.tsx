
export default function Home() {
  return (
    <>
    <p>Hello World</p>
    </>
  )
}


// 폴더는 소문자로 작성 
//파일 작성시 작명.tsx
// NextJs는 자동 라우터를 지원한다.
// import를 전역으로 사용하기 위해 layout에 적용한다.
// 적용위치는 {childern} 위쪽에 위치